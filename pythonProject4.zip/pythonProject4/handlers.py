
from aiogram import F,Router
from aiogram.types import message,CallbackQuery
from aiogram.filters import CommandStart,Command
from aiogram.fsm.state import StatesGroup,State
from aiogram.fsm.context import FSMContext

class Con(StatesGroup):
    add = State()
    rash = State()
    hg = State()
    fj = State()
class Balance(StatesGroup):
    doh = 0
    rash = 0
    bud = 0
    qw = 0
    bal = 0
    tr = False
router = Router()


@router.message(CommandStart())
async def start(message:message):
    await message.answer(f"""Функции бота : \n
    1. Доходы и расходы:/\n
- Команда /addincome [сумма] для добавления дохода.\n
- Команда /addexpense [сумма] для добавления расхода.\n
2. Просмотр баланса:\n
- Команда /balance для вывода текущего баланса (общая сумма доходов минус расходы).\n
3. Установка и отслеживание бюджета:\n
- Команда /setbudget [сумма] для установки месячного бюджета.\n
- Команда /budget для проверки текущего состояния бюджета.\n
4. Получение отчетов:\n
- Команда /report [период] для получения отчета о доходах и расходах за указанный период.\n
5. Напоминания о финансовых целях:\n
- Команда /setgoal [цель] [сумма] для установки финансовой цели.""")

@router.message(Command('addincome'))
async def addincome(message:message,state:FSMContext):
    await message.answer("Введите сумму в месяц через пробел пример '900'")
    await  state.set_state(Con.add)
    Balance.qw = 0
@router.message(Con.add)
async def AaDD(message:message,state:FSMContext):

    Balance.doh = int(message.text)
    print(Balance.doh)
    await state.clear()
@router.message(Command('addexpense'))
async def Rash(message:message,state:FSMContext):
    await message.answer("Введите сумму в месяц через пробел пример '900'")
    print(Balance.qw)
    await  state.set_state(Con.rash)
@router.message(Con.rash)
async def RASH(message:message,state:FSMContext):

    Balance.rash = int(message.text)
    ms =message.text
    print(ms)
    await state.clear()
@router.message(Command('balance'))
async def Balance(message:message):
    Balance.bal = Balance.doh - Balance.rash
    if Balance.bal < 0 :
        await message.answer("вам стоит увеличеть доход чтобы не обанкротиться")
    else:
        Balance.tr = True
    print(Balance.bal)
    await message.answer("Ваш баланс:"+str(Balance.bal))
@router.message(Command('setbudget'))
async def Setbudget(message:message,state:FSMContext):
    await message.answer('Введите сумму бюджета(она не должна привышать баланс)')
    await state.set_state(Con.hg)
@router.message(Con.hg)
async def st(message:message,state:FSMContext):
    if int(message.text) <= Balance.bal:
        await message.answer('Бюджет задан')
        Balance.bud = int(message.text)
    else:
        await message.answer('Данные введены неправильно')
    await state.clear()
@router.message(Command('budget'))
async def bud(messaage:message):
    await messaage.answer(f'Ваш бюджет:{Balance.bud}')



class Reg(StatesGroup):
    c = State()
    q = State()
    bl = State()
    qw = ''
    wq = ''


@router.message(Command('setgoal'))
async  def get_help(message:message,state:FSMContext):
    await  message.answer('Введите вашу цель и ваш бюджет на ее исполнение(напишите ок для обработки)')
    await state.set_state(Reg.q)
@router.message(Reg.q)
async def sell(message:message,state:FSMContext):
    await state.set_state(Reg.c)
    await message.answer('Введите цель:')
@router.message(Reg.c)
async def reg_two(message:message,state:FSMContext):
    await state.update_data(qw=message.text)
    await state.set_state(Reg.bl)
    await message.answer('Введите сумму, которая нужна:')

@router.message(Reg.bl)
async def two_three(message: message, state: FSMContext):
    await state.update_data(wq=message.text)
    data = await state.get_data()
    qw = data.get('qw')
    wq = data.get('wq')
    Balance.qw = qw
    Balance.wq = wq
    await message.answer(f'Ваша цель с бюджетом введены\n {qw} ваша цель \n {wq} ваш бюджет')
    await state.clear()
@router.message(Command('goals'))
async def ty(message:message):
    if Balance.tr == True:
        if Balance.bal>Balance.qw:
            await message.answer(f'Ваша цель:\n {Balance.qw}\n Вы выполнели вашу цель на:\n100%')
        else:
            www = Balance.bal/Balance.qw*100
            await message.answer(f'Ваша цель:\n {Balance.qw}\n Вы выполнели вашу цель на:\n{www} %')
    else:
        await message.answer(f'Ваша цель:\n {Balance.qw}\n Вы выполнели вашу цель на:\n0%')

@router.message(Command('report'))
async def rep(message:message,state:FSMContext):
    await state.set_state(Con.fj)
@router.message(Con.fj)
async def jd(message:message):
    await message.answer(f"через {message.text} месяцев"+str(Balance.bal * int(message.text)))
